function gotoLogin() {
    window.location.href = 'login.html'

}
// function guide() {
//     document.querySelector(".main_topics_div").hidden =true;

// }
// document.querySelector(".main_topics_div").hidden = false;
